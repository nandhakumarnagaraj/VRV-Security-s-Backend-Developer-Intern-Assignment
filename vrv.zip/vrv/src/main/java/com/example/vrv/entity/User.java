package com.example.vrv.entity;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor

public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Size(max = 50)
	@NotBlank
	private String username;
	@Size(max = 120)
	@NotBlank
	private String password;
	@ManyToMany(fetch = FetchType.LAZY)

	@JoinTable(name = "user_roles", // Name of the join table
			joinColumns = @JoinColumn(name = "user_id"), // Foreign key column for User
			inverseJoinColumns = @JoinColumn(name = "role_id") // Foreign key column for Role
	)
	private Set<Role> roles = new HashSet<>();

	public User(@Size(max = 50) @NotBlank String username, @Size(max = 120) @NotBlank String password) {
		super();
		this.username = username;
		this.password = password;
	}

}
