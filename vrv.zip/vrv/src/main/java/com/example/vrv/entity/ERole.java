package com.example.vrv.entity;

public enum ERole {
	ROLE_USER,
	ROLE_ADMIN,
	ROLE_MODERATOR

}
